#!/bin/sh
#HowTo: sudo bash myfile.sh open from a terminal

echo this script name is $0 
# $0 represent name of script
echo  \* "ヒラギノ角ゴ Pro W3.otf "
echo \* "ヒラギノ角ゴ Pro W6.otf"  
echo \* "Jesus.png" 
echo \* "treeview-background.svg"
echo \* "popup.svg"
#


